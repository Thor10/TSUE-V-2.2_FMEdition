# TSUE-V-2.2_FMEdition
TSUE V 2.2_FMEdition

I have no more time to do any more coding to this core

There is a new theme also a new in staller


Plateforms

Plateform 5.6.32

Plateform 5.6.40

Also Tested on https works a treat


Step 1: Upload the files

Upload the contents of the folder (DirRoot) All of the files to your RootDir . 

NOTE: Set Up Instructions - Please take note : (make sure those folders are accessible by chmod 0777). 

data/ 

data/announceLog 

data/avatars/l 

data/avatars/m 

data/avatars/s 

data/backups 

data/cache 

data/countryFlags 

data/downloads/files 

data/downloads/previews 

data/errors 

data/gallery/l 

data/gallery/s 

data/languageFlags 

data/posts 

data/smilies 

data/subTitles 

data/torrents/auto_uploader 

data/torrents/category_images 

data/torrents/imdb 

data/torrents/nfo 

Step 2: Install the application

Open include (library/config/database_config.php) Add all the Database info there 

Inport the Database in Database/database 

Step 3: Configure

Install

Point to http://yoursite.com/tsue_install/install.php

fill all field in

Delete the tsue_install

Login

Enter your Username

Enter your Password

SUBMIT
